export default [
    {
        id: 1,
        name: 'Hariom',
        age: '20year',
    },
    {
        id: 2,
        name: 'Hariom2',
        age: '21year',
    },
    {
        id: 3,
        name: 'Hariom3',
        age: '23year',
    },
    { 
        id: 4,
        name: 'Hariom4',
        age: '24year',
    },
    {
        id: 5,
        name: 'Hariom5',
        age: '25year',
    }
];  